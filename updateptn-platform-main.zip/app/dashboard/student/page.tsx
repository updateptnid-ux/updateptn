import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StaggerContainer, StaggerItem, MotionCard } from "@/components/ui/fade-in";
import { getUnivLogoUrl, getUnivInitials } from "@/lib/univ-logo";
import StudentTryoutList from "@/components/StudentTryoutList";
import {
  GraduationCap,
  FileText,
  Target,
  TrendingUp,
  Award,
} from "lucide-react";

// Force dynamic rendering and disable caching
// TODO: Move to ISR dengan revalidate setelah testing selesai
// export const revalidate = 60; // Cache 60 seconds
export const dynamic = 'force-dynamic';
export const fetchCache = 'force-no-store';

export default async function StudentDashboardPage() {
  const supabase = await createClient();

  // 1. Fetch user session
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  // If there's an error fetching user or no user found
  if (userError || !user) {
    console.error("Error fetching user:", userError);
    return (
      <div className="max-w-6xl mx-auto space-y-8 p-6">
        <div className="p-6 text-center bg-white rounded-lg shadow">
          <p className="text-slate-600 mb-4">Sesi tidak valid. Silakan login kembali.</p>
          <a href="/login" className="text-blue-600 hover:underline font-semibold">
            Kembali ke Login
          </a>
        </div>
      </div>
    );
  }

  // 2. Parallel data fetching untuk performa optimal
  const [
    { data: tryoutsData },
    { data: resultsData },
    { data: subData }
  ] = await Promise.all([
    supabase
      .from("tryouts")
      .select("*")
      .order("created_at", { ascending: false }),
    
    supabase
      .from("results")
      .select("*, tryouts(title)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }),
    
    supabase
      .from("subscriptions")
      .select("*")
      .eq("user_id", user.id)
      .gt("expires_at", new Date().toISOString())
      .order("expires_at", { ascending: false })
      .limit(1)
  ]);

  // 3. Process results
  const userResultsCount = resultsData?.length || 0;
  const lastResult = resultsData?.[0] || null;
  const activeSubscription = subData?.[0] || null;

  // Use real tryouts from database only
  const activeTryouts = tryoutsData && tryoutsData.length > 0 ? tryoutsData : [];

  const asalSekolah = user?.user_metadata?.asal_sekolah as string | undefined;
  const targetUniv = user?.user_metadata?.target_univ as string | undefined;
  const targetProdi = user?.user_metadata?.target_prodi as string | undefined;
  
  // Build a display label for the target
  const targetLabel =
    targetProdi && targetUniv
      ? `${targetProdi} — ${targetUniv.replace("UNIVERSITAS ", "").replace("INSTITUT ", "")}`
      : targetUniv || targetProdi || null;

  return (
    <div className="w-full min-h-screen bg-slate-50">
      <div className="max-w-4xl mx-auto p-3 md:p-4 space-y-3 md:space-y-4">
        {/* Header Banner - Compact */}
        <MotionCard className="rounded-lg md:rounded-xl">
          <div className="flex flex-col gap-3 bg-white p-3 md:p-4 rounded-lg md:rounded-xl border border-slate-200">
            <div className="space-y-1">
              <Badge variant="outline" className="text-[10px] bg-blue-50 text-blue-700 border-blue-200 font-semibold w-fit">
                Portal UTBK
              </Badge>
              <h1 className="text-base md:text-xl font-bold text-slate-900">
                Halo, {user?.user_metadata?.full_name || "Siswa"}! 👋
              </h1>
              <p className="text-xs md:text-sm text-slate-500">
                Pantau skor dan ikuti Try Out UTBK
              </p>
              {asalSekolah && (
                <p className="text-[10px] md:text-xs text-slate-400 flex items-center gap-1">
                  <span>🏫</span>
                  <span>{asalSekolah}</span>
                </p>
              )}
            </div>

            <Link href="/dashboard/student/cek-peluang" className="w-full">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg h-8 md:h-10 gap-2 text-xs md:text-sm touch-manipulation">
                <Target className="h-3 w-3 md:h-4 md:w-4" />
                <span>Cek Peluang PTN</span>
              </Button>
            </Link>
          </div>
        </MotionCard>

        {/* Stat Cards - Compact Grid */}
        <StaggerContainer className="grid grid-cols-3 gap-2 md:gap-3" staggerDelay={0.08}>
          {/* Stat 1 - Compact */}
          <StaggerItem>
            <MotionCard className="h-full rounded-lg md:rounded-xl">
              <Card className="bg-white border border-slate-200 p-2.5 md:p-4 rounded-lg md:rounded-xl space-y-1 md:space-y-2 h-full">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400">Total TO</span>
                  <div className="h-6 w-6 md:h-8 md:w-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <FileText className="h-3 w-3 md:h-4 md:w-4" />
                  </div>
                </div>
                <p className="text-xl md:text-2xl font-bold text-slate-900">{userResultsCount}</p>
                <p className="text-[9px] md:text-[10px] text-slate-500 font-medium">Diikuti</p>
              </Card>
            </MotionCard>
          </StaggerItem>

          {/* Stat 2 - Compact */}
          <StaggerItem>
            <MotionCard className="h-full rounded-lg md:rounded-xl">
              <Card className="bg-white border border-slate-200 p-2.5 md:p-4 rounded-lg md:rounded-xl space-y-1 md:space-y-2 h-full">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400">Skor</span>
                  <div className="h-6 w-6 md:h-8 md:w-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <Award className="h-3 w-3 md:h-4 md:w-4" />
                  </div>
                </div>
                <p className="text-xl md:text-2xl font-bold text-slate-900">
                  {lastResult ? Math.round(Number(lastResult.score)) : "—"}
                </p>
                <p className="text-[9px] md:text-[10px] text-slate-500 font-medium">
                  {lastResult ? "IRT" : "Belum ada"}
                </p>
              </Card>
            </MotionCard>
          </StaggerItem>

          {/* Stat 3 - Compact */}
          <StaggerItem>
            <MotionCard className="h-full rounded-lg md:rounded-xl">
              <Card className="bg-white border border-slate-200 p-2.5 md:p-4 rounded-lg md:rounded-xl space-y-1 md:space-y-2 h-full">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] md:text-[10px] font-bold uppercase tracking-wider text-slate-400">Target</span>
                  {targetUniv ? (
                    <Avatar className="h-6 w-6 md:h-8 md:w-8 rounded-lg border border-slate-200 shrink-0">
                      <AvatarImage
                        src={getUnivLogoUrl(targetUniv) ?? undefined}
                        alt={targetUniv}
                        className="object-contain p-0.5"
                      />
                      <AvatarFallback className="bg-blue-50 text-blue-600 font-bold text-[10px] rounded-lg">
                        {getUnivInitials(targetUniv)}
                      </AvatarFallback>
                    </Avatar>
                  ) : (
                    <div className="h-6 w-6 md:h-8 md:w-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                      <GraduationCap className="h-3 w-3 md:h-4 md:w-4" />
                    </div>
                  )}
                </div>
                {targetLabel ? (
                  <>
                    <p className="text-[10px] md:text-xs font-bold text-slate-900 leading-tight line-clamp-2">{targetLabel}</p>
                    <p className="text-[9px] md:text-[10px] text-blue-600 font-semibold flex items-center gap-0.5">
                      <Target className="h-2.5 w-2.5 md:h-3 md:w-3" />
                      <span>Impian</span>
                    </p>
                  </>
                ) : (
                  <>
                    <p className="text-[10px] md:text-xs font-semibold text-slate-400 italic">Belum diset</p>
                    <Link href="/direktori-prodi" className="text-[9px] md:text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5">
                      <TrendingUp className="h-2.5 w-2.5" />
                      <span>Cari →</span>
                    </Link>
                  </>
                )}
              </Card>
            </MotionCard>
          </StaggerItem>
        </StaggerContainer>

        {/* Active Subscription Info */}
        {activeSubscription && (
          <MotionCard className="rounded-lg md:rounded-xl">
            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 p-3 md:p-4 rounded-lg">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="h-10 w-10 md:h-12 md:w-12 rounded-lg bg-green-600 text-white flex items-center justify-center shrink-0">
                    {activeSubscription.tier === 'gold' ? '👑' : '⭐'}
                  </div>
                  <div>
                    <p className="text-xs md:text-sm font-bold text-green-900 capitalize">
                      Paket {activeSubscription.tier}
                    </p>
                    <p className="text-[10px] md:text-xs text-green-700">
                      Aktif hingga {new Date(activeSubscription.expires_at).toLocaleDateString('id-ID', { 
                        day: 'numeric', 
                        month: 'long', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                </div>
                <Badge className="bg-green-600 text-white border-0 text-[10px] md:text-xs font-bold">
                  AKTIF
                </Badge>
              </div>
            </Card>
          </MotionCard>
        )}

        {/* Try Outs List - Compact */}
        <StudentTryoutList
          tryouts={activeTryouts}
          userId={user.id}
          userName={user.user_metadata?.full_name || ""}
          userEmail={user.email || ""}
          initialSubscription={activeSubscription}
        />
      </div>
    </div>
  );
}
